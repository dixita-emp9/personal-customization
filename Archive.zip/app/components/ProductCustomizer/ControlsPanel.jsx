import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import useCustomizerStore from '../../store/useCustomizerStore';
import { clsx } from 'clsx';
// Import Panels (will create these next)
import { LettersPatchesPanel } from './panels/LettersPatchesPanel';
import { EmbroideryPanel } from './panels/EmbroideryPanel';
import { VinylPanel } from './panels/VinylPanel';
import { ColorOptionPanel } from './panels/ColorOptionPanel';

const OPTIONS = [
    { id: 'color', label: 'Pick Personalisation (Color)' },
    { id: 'letters_patches', label: 'Letters & Patches' },
    { id: 'embroidery', label: 'Embroidery' },
    { id: 'vinyl', label: 'Cricut/Vinyl' },
];

export function ControlsPanel({ product, variants, lettersCollection, patchesCollection }) {
    const { mode, setMode, baseProduct } = useCustomizerStore();
    const [isOpen, setIsOpen] = useState(true);

    const renderActivePanel = () => {
        switch (mode) {
            case 'color':
                return <ColorOptionPanel product={product} variants={variants} />;
            case 'letters_patches':
                return <LettersPatchesPanel lettersCollection={lettersCollection} patchesCollection={patchesCollection} />;
            case 'embroidery':
                return <EmbroideryPanel />;
            case 'vinyl':
                return <VinylPanel />;
            default:
                return null;
        }
    };

    return (
        <div className="flex flex-col h-full">
            {/* Product Info Header */}
            <div className="p-6 border-b border-gray-100">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{baseProduct?.title || 'Product'}</h1>
                <p className="text-gray-500 mb-4">Customize your unique product below.</p>

                {/* Dropdown Selector for Mode */}
                <div className="relative">
                    <button
                        onClick={() => setIsOpen(!isOpen)}
                        className="w-full flex items-center justify-between p-4 bg-white border border-gray-300 rounded-lg hover:border-pink-500 transition-colors"
                    >
                        <span className="font-medium text-gray-700">
                            {OPTIONS.find(o => o.id === mode)?.label}
                        </span>
                        {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </button>

                    {isOpen && (
                        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-xl z-20 overflow-hidden">
                            {OPTIONS.map((opt) => (
                                <button
                                    key={opt.id}
                                    onClick={() => {
                                        setMode(opt.id);
                                        setIsOpen(false);
                                    }}
                                    className={clsx(
                                        "w-full text-left px-4 py-3 hover:bg-pink-50 transition-colors border-b border-gray-100 last:border-0",
                                        mode === opt.id ? "bg-pink-50 text-pink-600 font-medium" : "text-gray-700"
                                    )}
                                >
                                    {opt.label}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Active Panel Content */}
            <div className="flex-1 overflow-y-auto p-6 bg-gray-50/50">
                {renderActivePanel()}
            </div>

            {/* Footer / Cart Actions */}
            <div className="p-6 bg-white border-t border-gray-200 mt-auto">
                <div className="flex items-center justify-between mb-4">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="text-xl font-bold text-gray-900">
                        {/* Placeholder price logic */}
                        AED {((baseProduct?.price || 0) + 0).toFixed(2)}
                    </span>
                </div>

                <div className="flex gap-3">
                    <button className="flex-1 py-3 px-6 border border-gray-300 rounded-full font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                        Back
                    </button>
                    <button className="flex-[2] py-3 px-6 bg-pink-500 text-white rounded-full font-bold hover:bg-pink-600 transition-colors shadow-lg shadow-pink-200">
                        Add to Bag
                    </button>
                </div>
            </div>
        </div>
    );
}
