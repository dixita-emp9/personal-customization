import React, { useRef, useEffect } from 'react';
import { Stage, Layer, Image as KonvaImage, Text, Transformer, Circle, Group } from 'react-konva';
import useImage from 'use-image';
import { X } from 'lucide-react';
import useCustomizerStore from '../../store/useCustomizerStore';

const URLImage = ({ image, ...props }) => {
    const [img] = useImage(image.src || image);

    // Auto-scale huge images when they first load
    useEffect(() => {
        if (img && props.nodeRef?.current) {
            // If it's a new drop (scale is 1) and image is huge, shrink it
            const node = props.nodeRef.current;
            if (node.scaleX() === 1 && (img.width > 200 || img.height > 200)) {
                const scale = 200 / Math.max(img.width, img.height);
                node.scaleX(scale);
                node.scaleY(scale);
                // We need to sync this back to store ideally, but for display this works until touched
            }
        }
    }, [img]);

    return <KonvaImage image={img} {...props} />;
};

const CanvasObject = ({ obj, isSelected, onSelect, onChange, stageWidth, stageHeight }) => {
    const shapeRef = useRef();
    const trRef = useRef();

    useEffect(() => {
        if (isSelected && trRef.current && shapeRef.current) {
            trRef.current.nodes([shapeRef.current]);
            trRef.current.getLayer().batchDraw();
        }
    }, [isSelected]);

    const dragBoundFunc = (pos) => {
        // Restrict to stage dimensions with some padding
        const r = 20; // radius/padding
        const x = Math.max(r, Math.min(stageWidth - r, pos.x));
        const y = Math.max(r, Math.min(stageHeight - r, pos.y));
        return { x, y };
    };

    const commonProps = {
        onClick: onSelect,
        onTap: onSelect,
        ref: shapeRef,
        ...obj,
        draggable: true,
        dragBoundFunc, // Apply constraint
        onDragEnd: (e) => {
            onChange({
                x: e.target.x(),
                y: e.target.y(),
            });
        },
        onTransformEnd: (e) => {
            const node = shapeRef.current;
            onChange({
                x: node.x(),
                y: node.y(),
                scaleX: node.scaleX(),
                scaleY: node.scaleY(),
                rotation: node.rotation(),
            });
        },
    };

    return (
        <React.Fragment>
            {obj.type === 'embroidery' ? (
                <Text
                    {...commonProps}
                    text={obj.text}
                    fontFamily={obj.fontFamily}
                    fontSize={obj.fontSize || 30}
                    fill={obj.color}
                />
            ) : (
                <URLImage
                    {...commonProps}
                    nodeRef={shapeRef}
                    image={obj.image}
                />
            )}

            {isSelected && (
                <Transformer
                    ref={trRef}
                    enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']} // Keep aspect ratio scaling
                    boundBoxFunc={(oldBox, newBox) => {
                        // Limit minimum size
                        if (newBox.width < 20 || newBox.height < 20) {
                            return oldBox;
                        }
                        return newBox;
                    }}
                />
            )}
        </React.Fragment>
    );
};

export function CustomizerCanvas() {
    const {
        baseProduct,
        canvasObjects,
        selectedObjectId,
        selectObject,
        updateObject,
        addObject,
        removeObject,
        width,
        height
    } = useCustomizerStore();

    const stageRef = useRef(null);
    const [baseImage] = useImage(baseProduct?.image || '');

    const checkDeselect = (e) => {
        const clickedOnEmpty = e.target === e.target.getStage();
        const clickedOnBase = e.target.hasName('base-image');

        if (clickedOnEmpty || clickedOnBase) {
            selectObject(null);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        stageRef.current.setPointersPositions(e);

        const itemData = e.dataTransfer.getData('application/json');
        if (!itemData) return;

        const item = JSON.parse(itemData);

        const stage = stageRef.current;
        const pointerPosition = stage.getPointerPosition();

        addObject({
            ...item,
            id: `${item.type}-${Date.now()}`,
            x: pointerPosition.x,
            y: pointerPosition.y,
            scaleX: 1, // Start 1:1, URLImage will auto-shrink if too big
            scaleY: 1,
            rotation: 0,
        });
    };

    const handleDeleteSelected = () => {
        if (selectedObjectId) {
            removeObject(selectedObjectId);
        }
    }

    return (
        <div
            className="shadow-lg border border-gray-200 bg-white relative group"
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
        >
            {/* Delete Button Overlay */}
            {selectedObjectId && (
                <button
                    onClick={handleDeleteSelected}
                    className="absolute top-4 right-4 z-10 bg-white p-2 rounded-full text-red-500 shadow-md hover:bg-red-50 transition-all border border-gray-200"
                    title="Remove Selected Item"
                >
                    <X size={20} />
                </button>
            )}

            <Stage
                width={width}
                height={height}
                onMouseDown={checkDeselect}
                onTouchStart={checkDeselect}
                ref={stageRef}
            >
                <Layer>
                    {/* Base Product Image */}
                    {baseImage && (
                        <KonvaImage
                            name="base-image"
                            image={baseImage}
                            width={width}
                            height={height}
                            fit="contain" // Need to handle aspect ratio properly in real impl
                        />
                    )}

                    {/* Canvas Objects */}
                    {canvasObjects.map((obj) => (
                        <CanvasObject
                            key={obj.id}
                            obj={obj}
                            isSelected={obj.id === selectedObjectId}
                            onSelect={() => selectObject(obj.id)}
                            onChange={(newAttrs) => updateObject(obj.id, newAttrs)}
                            stageWidth={width}
                            stageHeight={height}
                        />
                    ))}
                </Layer>
            </Stage>
        </div>
    );
}
